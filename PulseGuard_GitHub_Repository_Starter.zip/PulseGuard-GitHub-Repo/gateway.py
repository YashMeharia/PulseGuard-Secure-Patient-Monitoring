import socket
import threading
import json
import hashlib
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.exceptions import InvalidTag

HOST = "0.0.0.0"
PORT = 5000
WEB_HOST = "127.0.0.1"
WEB_PORT = 8080
LOG_FILE = "security_alerts.jsonl"

# DHCP addresses observed in the user's current four-board serial-monitor test.
# These IP-based labels work with the existing firmware handshake, which currently
# sends an ECDH public key but does not send an authenticated device ID.
# If the hotspot changes these leases, update this map or add DHCP reservations.
DEVICE_PROFILES = {
    "192.168.1.7": {"name": "ESP32-01", "node_id": "NODE-01", "sensors": "MAX30102 + DHT11"},
    "192.168.1.9": {"name": "ESP32-02", "node_id": "NODE-02", "sensors": "MAX30102"},
    "192.168.1.8":   {"name": "ESP32-03", "node_id": "NODE-03", "sensors": "DHT11"},
    "192.168.1.6":  {"name": "ESP32-04", "node_id": "NODE-04", "sensors": "DHT11"},
}

PRINT_LOCK = threading.Lock()
STATE_LOCK = threading.Lock()
CLIENT_LABELS = {}
CLIENT_COUNTER = 0
DASHBOARD_CLIENTS = {}
SECURITY_EVENTS = []

def safe_print(*args, **kwargs):
    with PRINT_LOCK:
        print(*args, **kwargs)

def get_client_label(peer):
    global CLIENT_COUNTER
    # Stable configured node label based on the current DHCP IP assignment.
    # Reserve the IP leases so a board keeps the same NODE number after reconnecting.
    profile = DEVICE_PROFILES.get(peer[0])
    if profile:
        return profile["node_id"]
    key = peer[0]
    with PRINT_LOCK:
        if key not in CLIENT_LABELS:
            CLIENT_COUNTER += 1
            CLIENT_LABELS[key] = f"UNKNOWN-{CLIENT_COUNTER:02d}"
        return CLIENT_LABELS[key]


def device_profile(peer_ip, client_label):
    profile = DEVICE_PROFILES.get(peer_ip)
    if profile:
        return profile["name"], profile["sensors"]
    return client_label, "Sensor profile not mapped"


def update_client(client_label, peer, **changes):
    name, sensors = device_profile(peer[0], client_label)
    with STATE_LOCK:
        current = DASHBOARD_CLIENTS.setdefault(client_label, {
            "client_id": client_label, "device_name": name, "sensors": sensors,
            "ip": peer[0], "port": peer[1], "connected": False, "secure": False,
            "last_seen": None, "sequence": None, "hr": "—", "spo2": "—",
            "temp": "—", "hum": "—", "status": "Waiting for data"
        })
        current.update(changes)
        current["device_name"] = name
        current["sensors"] = sensors
        current["ip"] = peer[0]
        current["port"] = peer[1]
        current["last_seen"] = datetime.now(timezone.utc).isoformat()


def add_dashboard_event(kind, message, severity="INFO", peer=None, details=None):
    now_local = datetime.now().astimezone()
    event = {
        "time": now_local.strftime("%H:%M:%S"),
        "date_time_local": now_local.isoformat(timespec="seconds"),
        "kind": kind, "message": message, "severity": severity,
        "ip": peer[0] if peer else "Gateway"
    }
    if details:
        event.update(details)
    with STATE_LOCK:
        SECURITY_EVENTS.insert(0, event)
        del SECURITY_EVENTS[100:]
    return event


def parse_sensor_message(message):
    values = {}
    for item in message.split(","):
        if "=" in item:
            key, value = item.split("=", 1)
            values[key.strip()] = value.strip()
    return values

def print_client_packet(label, peer, message):
    values = parse_sensor_message(message)
    update_client(
        label, peer, sequence=values.get("SEQ", "—"),
        hr=values.get("HR", "—"), spo2=values.get("SpO2", "—"),
        temp=values.get("TEMP", "—"), hum=values.get("HUM", "—"),
        status="Receiving encrypted sensor data", connected=True, secure=True
    )
    safe_print("\n" + "=" * 64)
    safe_print(f" {label}  |  IP: {peer[0]}  |  PORT: {peer[1]}")
    safe_print("-" * 64)
    safe_print(f" Sequence    : {values.get('SEQ', 'N/A')}")
    safe_print(f" Heart Rate  : {values.get('HR', 'N/A')}")
    safe_print(f" SpO2        : {values.get('SpO2', 'N/A')}")
    safe_print(f" Temperature : {values.get('TEMP', 'N/A')} °C")
    safe_print(f" Humidity    : {values.get('HUM', 'N/A')} %")
    safe_print(" Security    : AES-256-GCM authenticated")
    safe_print("=" * 64, flush=True)


def log_event(event_type, severity, peer, reason, sequence=None, packet_hash=None,
              category=None, detection_method=None, suspected_change=None,
              evidence=None, action="rejected"):
    now_utc = datetime.now(timezone.utc)
    profile = DEVICE_PROFILES.get(peer[0], {})
    device_name = profile.get("name", "Unmapped ESP32")
    node_id = profile.get("node_id", "UNKNOWN")
    now_local = now_utc.astimezone()

    event = {
        "timestamp_utc": now_utc.isoformat(timespec="milliseconds"),
        "timestamp_local": now_local.isoformat(timespec="seconds"),
        "event": event_type,
        "category": category or event_type,
        "severity": severity,
        "device_name": device_name,
        "node_id": node_id,
        "source_ip": peer[0],
        "source_port": peer[1],
        "sequence": sequence,
        "reason": reason,
        "detection_method": detection_method,
        "suspected_change": suspected_change,
        "evidence": evidence,
        "packet_sha256": packet_hash,
        "action": action
    }
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(json.dumps(event) + "\n")

    dashboard_details = {
        "date_time_local": event["timestamp_local"],
        "device_name": device_name,
        "node_id": node_id,
        "category": event["category"],
        "sequence": sequence,
        "detection_method": detection_method,
        "suspected_change": suspected_change,
        "evidence": evidence,
        "packet_sha256": packet_hash,
        "action_taken": action
    }
    add_dashboard_event(event_type, reason, severity, peer, dashboard_details)
    safe_print("\n[SECURITY ALERT] " + json.dumps(event), flush=True)


def recv_line(conn, buffer=b""):
    while b"\n" not in buffer:
        chunk = conn.recv(4096)
        if not chunk:
            return None, buffer
        buffer += chunk
    line, buffer = buffer.split(b"\n", 1)
    return line.rstrip(b"\r"), buffer

def from_hex(value):
    if len(value) % 2:
        raise ValueError("Odd-length hexadecimal field")
    return bytes.fromhex(value.decode("ascii"))

def recv_client_ecpoint(conn):
    """
    ESP32 firmware sends mbedTLS ECDH public payload as ASCII hex
    followed by newline (client.println(toHex(...))).
    The payload includes the one-byte ECPoint length prefix.
    """
    data = bytearray()
    while True:
        chunk = conn.recv(1)
        if not chunk:
            raise ConnectionError("Client disconnected during ECDH public key")
        if chunk == b"\n":
            break
        if chunk != b"\r":
            data.extend(chunk)
        if len(data) > 512:
            raise ValueError("ECDH public-key line is too long")

    try:
        line = data.decode("ascii").strip()
        if not line:
            raise ValueError("Empty ECDH public-key line")
        payload = bytes.fromhex(line)
    except (UnicodeDecodeError, ValueError) as exc:
        raise ValueError("Expected newline-terminated ASCII hexadecimal ECDH payload") from exc

    return payload


def handle_client(conn, peer):
    client_label = get_client_label(peer)
    safe_print(f"\n[CONNECTED] {client_label} | {peer[0]}:{peer[1]}", flush=True)
    last_sequence = 0

    try:
        client_payload = recv_client_ecpoint(conn)
        if client_payload is None:
            return

        if len(client_payload) != 66 or client_payload[0] != 65:
            raise ValueError(
                f"Unexpected ECPoint framing: got {len(client_payload)} bytes; "
                "expected 66 bytes with a 0x41 length prefix"
            )

        client_public_bytes = client_payload[1:]
        client_public_key = ec.EllipticCurvePublicKey.from_encoded_point(
            ec.SECP256R1(), client_public_bytes
        )

        server_private_key = ec.generate_private_key(ec.SECP256R1())
        server_public_bytes = server_private_key.public_key().public_bytes(
            encoding=serialization.Encoding.X962,
            format=serialization.PublicFormat.UncompressedPoint
        )
        server_payload = bytes([len(server_public_bytes)]) + server_public_bytes

        # ESP32 readLine() expects ASCII hex terminated by LF.
        conn.sendall(server_payload.hex().encode("ascii") + b"\n")

        shared_secret = server_private_key.exchange(ec.ECDH(), client_public_key)
        aes_key = HKDF(
            algorithm=hashes.SHA256(),
            length=32,
            salt=None,
            info=b"PatientMonitoring"
        ).derive(shared_secret)

        update_client(client_label, peer, connected=True, secure=True, status="Secure session established")
        add_dashboard_event("SECURE SESSION", f"{client_label}: AES-256-GCM session established", "SUCCESS", peer)
        safe_print(
            f"[SECURE] {client_label} | P-256 ECDH + HKDF-SHA256 complete "
            "| AES-256-GCM session ready",
            flush=True
        )

        buffer = b""
        while True:
            line, buffer = recv_line(conn, buffer)
            if line is None:
                break
            if not line:
                continue

            packet_hash = hashlib.sha256(line).hexdigest()

            try:
                fields = line.decode("ascii").split("|")
                if len(fields) != 3:
                    raise ValueError("Expected NONCE|CIPHERTEXT|TAG")

                nonce = bytes.fromhex(fields[0])
                ciphertext = bytes.fromhex(fields[1])
                tag = bytes.fromhex(fields[2])

                if len(nonce) != 12 or len(tag) != 16:
                    raise ValueError("Invalid nonce or authentication-tag length")

                plaintext = AESGCM(aes_key).decrypt(nonce, ciphertext + tag, None)
                message = plaintext.decode("utf-8", errors="replace")

                seq = None
                for item in message.split(","):
                    if item.startswith("SEQ="):
                        seq = int(item.split("=", 1)[1])
                        break
                if seq is None:
                    raise ValueError("Missing SEQ field")

                if seq <= last_sequence:
                    log_event(
                        "REPLAY_DETECTED", "HIGH", peer,
                        f"Repeated/old sequence {seq}; last accepted sequence was {last_sequence}.",
                        seq, packet_hash,
                        category="REPLAY ATTACK",
                        detection_method="Sequence-number validation",
                        suspected_change="Previously accepted encrypted packet was resent; payload alteration is not required.",
                        evidence=f"Received sequence={seq}; last accepted sequence={last_sequence}.",
                        action="rejected"
                    )
                    continue

                last_sequence = seq
                print_client_packet(client_label, peer, message)

            except InvalidTag:
                log_event(
                    "PACKET_REJECTED", "HIGH", peer,
                    "AES-256-GCM authentication failed (InvalidTag). The received packet did not authenticate.",
                    packet_hash=packet_hash,
                    category="POSSIBLE PACKET TAMPERING",
                    detection_method="AES-256-GCM authentication-tag verification",
                    suspected_change=(
                        "Ciphertext, authentication tag, nonce, or packet bytes may have been modified "
                        "or corrupted. The gateway cannot identify the exact changed byte from this packet alone."
                    ),
                    evidence=(
                        "Python AESGCM.decrypt() raised InvalidTag. The packet SHA-256 fingerprint is recorded. "
                        "The sequence number is inside encrypted plaintext and is unavailable when authentication fails."
                    ),
                    action="rejected; plaintext not accepted"
                )
            except Exception as exc:
                log_event(
                    "PACKET_REJECTED", "HIGH", peer,
                    f"Packet format/decryption/validation failed: {type(exc).__name__}",
                    packet_hash=packet_hash,
                    category="INVALID OR MALFORMED PACKET",
                    detection_method="Packet parser and validation",
                    suspected_change="Malformed, truncated, corrupted, or incorrectly formatted packet.",
                    evidence=f"Exception type: {type(exc).__name__}; packet SHA-256 recorded.",
                    action="rejected"
                )

    except Exception as exc:
        log_event(
            "HANDSHAKE_FAILED", "HIGH", peer,
            f"Handshake/protocol error: {type(exc).__name__}"
        )
        update_client(client_label, peer, connected=False, secure=False, status=f"Handshake/error: {type(exc).__name__}")
        safe_print(f"[ERROR] {client_label} {peer}: {exc}", flush=True)
    finally:
        try:
            conn.close()
        except Exception:
            pass
        update_client(client_label, peer, connected=False, secure=False, status="Disconnected")
        add_dashboard_event("DISCONNECTED", f"{client_label} disconnected", "WARNING", peer)
        safe_print(f"[DISCONNECTED] {client_label} | {peer[0]}:{peer[1]}", flush=True)



DASHBOARD_HTML = r"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>PulseGuard | Secure Patient Monitoring</title>
<style>
:root{--bg:#f4f7fb;--panel:#fff;--ink:#172033;--muted:#738096;--line:#e6ebf2;--blue:#2563eb;--navy:#101a2e;--green:#16a36a;--red:#dc4545;--amber:#d58a19;--shadow:0 8px 28px rgba(25,42,70,.06)}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:14px/1.5 Inter,system-ui,-apple-system,"Segoe UI",sans-serif}
.layout{min-height:100vh;display:grid;grid-template-columns:235px 1fr}.sidebar{background:var(--navy);color:#eaf0ff;padding:26px 18px;display:flex;flex-direction:column;gap:27px}
.brand{display:flex;align-items:center;gap:12px;padding:0 8px}.logo{height:38px;width:38px;border-radius:12px;background:#2e6be6;display:grid;place-items:center;font-size:21px}.brand strong{font-size:17px}.brand small{display:block;color:#9cabc5;font-size:10px;letter-spacing:1px}
.nav-label{color:#8190aa;font-size:10px;font-weight:800;letter-spacing:1.3px;padding:0 10px;margin-bottom:-15px}.nav-item{padding:11px 12px;border-radius:10px;color:#b9c5d9;display:flex;gap:11px;align-items:center;text-decoration:none;min-height:46px}.nav-item:hover{background:#182944;color:#fff}.nav-item.active{background:#1e3153;color:#fff}.nav-icon{width:18px;text-align:center}
.side-foot{margin-top:auto;border-top:1px solid #26344c;padding:18px 8px 0;color:#93a2bb;font-size:11px}
main{padding:30px 34px 40px;max-width:1600px;width:100%;margin:auto}.topbar{display:flex;justify-content:space-between;align-items:center;gap:18px;margin-bottom:26px}
.eyebrow{color:var(--blue);font-size:11px;font-weight:800;letter-spacing:1.2px;text-transform:uppercase}.topbar h1{font-size:26px;margin:3px 0 0;letter-spacing:-.7px}.top-actions{display:flex;align-items:center;gap:12px}
.live-pill{border:1px solid #ccebdc;background:#effaf4;color:#138653;padding:7px 11px;border-radius:30px;font-size:12px;font-weight:700}.dot{display:inline-block;width:7px;height:7px;border-radius:50%;background:#19ae6c;margin-right:7px;box-shadow:0 0 0 3px #d7f3e4}.updated{font-size:11px;color:var(--muted)}
.metrics{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:16px;margin-bottom:22px}.metric,.panel,.device{background:var(--panel);border:1px solid var(--line);border-radius:15px;box-shadow:var(--shadow)}
.metric{padding:18px 19px;display:flex;justify-content:space-between;align-items:flex-start}.metric-label{color:var(--muted);font-size:12px;font-weight:600}.metric-value{font-size:29px;font-weight:750;letter-spacing:-1px;margin-top:7px}.metric-note{color:var(--muted);font-size:11px;margin-top:2px}.metric-icon{width:38px;height:38px;border-radius:11px;display:grid;place-items:center;font-size:17px;background:#edf3ff;color:#346be0}
.section-head{display:flex;align-items:end;justify-content:space-between;margin:25px 0 13px}.section-head h2{font-size:17px;margin:0}.section-head p{font-size:11px;color:var(--muted);margin:3px 0 0}
.devices{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}.device{padding:18px 19px}.device-top{display:flex;justify-content:space-between;align-items:flex-start;gap:12px}.device-name{font-size:15px;font-weight:750}.device-meta{font-size:11px;color:var(--muted);margin-top:2px}
.status{font-size:10px;font-weight:800;border-radius:20px;padding:5px 9px;white-space:nowrap;background:#f0f2f5;color:#788396}.status.online{background:#eaf8f1;color:#148552}.status.offline{background:#fff0f0;color:#c43d3d}.status.handshake{background:#fff6e7;color:#a96a0d}
.sensor-tag{display:inline-block;background:#f2f5fa;color:#53627a;border-radius:6px;padding:4px 7px;font-size:10px;margin-top:10px}.readings{display:grid;grid-template-columns:repeat(4,1fr);gap:9px;margin-top:16px}
.reading{background:#f7f9fc;border:1px solid #edf0f5;border-radius:10px;padding:11px 10px}.reading-label{font-size:10px;color:var(--muted);font-weight:650}.reading-value{font-size:19px;font-weight:750;margin-top:5px;white-space:nowrap}.unit{font-size:10px;color:var(--muted);font-weight:500}
.device-bottom{border-top:1px solid var(--line);margin-top:14px;padding-top:11px;display:flex;justify-content:space-between;gap:10px;color:var(--muted);font-size:10px}
.lower{display:grid;grid-template-columns:1.1fr .9fr;gap:16px;margin-top:20px}.panel{padding:18px 19px;min-width:0}.panel h3{font-size:14px;margin:0}.panel-sub{font-size:11px;color:var(--muted);margin:3px 0 13px}
.event-list{display:flex;flex-direction:column;max-height:270px;overflow:auto}.event{display:grid;grid-template-columns:68px 1fr auto;gap:10px;align-items:start;padding:10px 0;border-top:1px solid #f0f2f6}.event:first-child{border-top:0}.event-time{font-size:10px;color:var(--muted);font-variant-numeric:tabular-nums}.event-msg{font-size:11px;overflow-wrap:anywhere}.event-kind{font-size:9px;font-weight:800;letter-spacing:.4px}.sev-INFO{color:#3972d8}.sev-SUCCESS{color:#15935d}.sev-WARNING{color:#b87912}.sev-HIGH,.sev-CRITICAL{color:#d43d3d}
.security-box{background:#f8fafc;border:1px solid #edf0f5;border-radius:11px;padding:13px;margin-top:12px}.security-row{display:flex;justify-content:space-between;gap:10px;padding:8px 0;border-bottom:1px solid #e9edf3;font-size:11px}.security-row:last-child{border:0}.security-row strong{font-variant-numeric:tabular-nums}.investigation{margin-top:14px;padding:14px;border:1px solid #f1caca;background:#fffafa;border-radius:12px}
.investigation-title{font-weight:800;font-size:13px;margin-bottom:9px;color:#9e3030}
.investigation-empty{font-size:12px;color:var(--muted)}
.investigation-grid{display:grid;grid-template-columns:1fr 1fr;gap:9px}
.investigation-field{padding:8px;background:#fff;border:1px solid #f0e2e2;border-radius:8px;min-width:0}
.investigation-field small{display:block;color:var(--muted);font-size:10px;font-weight:800;text-transform:uppercase;letter-spacing:.4px}
.investigation-field strong{display:block;font-size:12px;overflow-wrap:anywhere;margin-top:3px}
.investigation-wide{grid-column:1/-1}
.investigation-status{display:inline-block;padding:3px 8px;border-radius:99px;background:#fee8e8;color:#a72d2d;font-size:10px;font-weight:900;margin-bottom:8px}
@media(max-width:700px){.investigation-grid{grid-template-columns:1fr}.investigation-wide{grid-column:auto}}
.footer-note{font-size:10px;color:#8995a8;text-align:center;margin:22px 0 0}
@media(max-width:1050px){.layout{grid-template-columns:190px 1fr}.metrics{grid-template-columns:repeat(2,1fr)}}@media(max-width:760px){.layout{display:block}.sidebar{display:none}main{padding:22px 15px}.topbar{align-items:flex-start;flex-direction:column}.devices,.lower{grid-template-columns:1fr}.readings{grid-template-columns:repeat(2,1fr)}.topbar h1{font-size:22px}}
</style></head>
<body><div class="layout"><aside class="sidebar">
<div class="brand"><div class="logo">✚</div><div><strong>PulseGuard</strong><small>SECURE MONITORING</small></div></div>
<div class="nav-label">WORKSPACE</div>
<a class="nav-item active" href="#overview"><span class="nav-icon">▦</span>Overview</a>
<a class="nav-item" href="#connected-devices"><span class="nav-icon">⌁</span>Connected devices</a>
<a class="nav-item" href="#security-center"><span class="nav-icon">◈</span>Security center</a>
<a class="nav-item" href="#activity-logs"><span class="nav-icon">▤</span>Activity logs</a>
<div class="side-foot">LOCAL GATEWAY<br>TCP :5000 • WEB :8080<br><br>Patient Monitoring Prototype</div></aside>
<main id="overview"><header class="topbar"><div><div class="eyebrow">Monitoring workspace</div><h1>Patient Monitoring Overview</h1></div><div class="top-actions"><div class="live-pill"><span class="dot"></span>LIVE UPDATES</div><div class="updated" id="updated">Connecting…</div></div></header>
<section class="metrics">
<div class="metric"><div><div class="metric-label">Connected devices</div><div class="metric-value" id="connected">0 / 4</div><div class="metric-note">ESP32 nodes online</div></div><div class="metric-icon">⌁</div></div>
<div class="metric"><div><div class="metric-label">Secure sessions</div><div class="metric-value" id="secure">0</div><div class="metric-note">AES-256-GCM active</div></div><div class="metric-icon">◇</div></div>
<div class="metric"><div><div class="metric-label">Security alerts</div><div class="metric-value" id="alerts">0</div><div class="metric-note">Rejected or suspicious packets</div></div><div class="metric-icon">⚑</div></div>
<div class="metric"><div><div class="metric-label">Gateway status</div><div class="metric-value" id="gateway" style="font-size:22px">ONLINE</div><div class="metric-note">Listening on TCP port 5000</div></div><div class="metric-icon">⌘</div></div></section>
<div class="section-head" id="connected-devices"><div><h2>Device monitoring</h2><p>Latest decrypted readings from each connected ESP32</p></div><div class="updated">Auto-refresh every 1.5 seconds</div></div>
<section class="devices" id="devices"></section>
<section class="lower" id="activity-logs"><div class="panel"><h3>Recent activity</h3><div class="panel-sub">Device connections and security events</div><div class="event-list" id="events"><div class="updated">Waiting for events…</div></div></div>
<div class="panel" id="security-center"><h3>Security center</h3><div class="panel-sub">Transport protection and packet validation</div><div class="security-box">
<div class="security-row"><span>Encryption</span><strong>AES-256-GCM</strong></div><div class="security-row"><span>Key agreement</span><strong>P-256 ECDH</strong></div><div class="security-row"><span>Key derivation</span><strong>HKDF-SHA256</strong></div><div class="security-row"><span>Replay protection</span><strong>Sequence check</strong></div><div class="security-row"><span>Authentication failures</span><strong id="failed">0</strong></div></div>
<div class="investigation" id="attack-investigation">
<div class="investigation-title">Attack investigation</div>
<div class="investigation-empty">No tampering or replay event recorded yet. Run a controlled test to populate this panel.</div>
</div>
<div class="panel-sub" style="margin-top:12px">Prototype demonstration only. InvalidTag indicates authentication failure; it does not by itself identify an attacker or the exact modified byte.</div></div></section>
<div class="footer-note">PulseGuard • Local dashboard • Readings are not for clinical diagnosis.</div></main></div>
<script>
const known=[{name:"ESP32-01",sensors:"MAX30102 + DHT11",ip:"192.168.1.7"},{name:"ESP32-02",sensors:"MAX30102",ip:"192.168.1.9"},{name:"ESP32-03",sensors:"DHT11",ip:"192.168.1.8"},{name:"ESP32-04",sensors:"DHT11",ip:"192.168.1.6"}];
function node(t,c,txt){let n=document.createElement(t);if(c)n.className=c;if(txt!==undefined)n.textContent=txt;return n}
function val(v){return v===undefined||v===null||v===""?"—":String(v)}
function card(d){let c=node("article","device"),top=node("div","device-top"),left=node("div","");
left.append(node("div","device-name",d.device_name||d.client_id),node("div","device-meta",`${d.ip||"—"} • ${d.client_id||""}`));
top.append(left,node("span","status "+(d.connected?(d.secure?"online":"handshake"):"offline"),d.connected?(d.secure?"ONLINE · SECURE":"HANDSHAKE"):"OFFLINE"));c.append(top,node("span","sensor-tag",d.sensors||"Sensor profile not mapped"));
const sensorText=(d.sensors||"").toUpperCase();
const hasMax=sensorText.includes("MAX30102");
const hasDht=sensorText.includes("DHT11");
const temp=(d.temp===-1||d.temp==="-1.0"||d.temp==="-1")?"N/A":d.temp;
const hum=(d.hum===-1||d.hum==="-1.0"||d.hum==="-1")?"N/A":d.hum;
const hr=hasMax?d.hr:"N/A";
const spo2=hasMax?d.spo2:"N/A";
const temperature=hasDht?temp:"N/A";
const humidity=hasDht?hum:"N/A";
let grid=node("div","readings");[["Heart rate",hr,"bpm"],["SpO₂",spo2,"%"],["Temperature",temperature,"°C"],["Humidity",humidity,"%"]].forEach(([l,v,u])=>{let b=node("div","reading");b.append(node("div","reading-label",l));let x=node("div","reading-value");x.append(document.createTextNode(val(v)+" "),node("span","unit",u));b.append(x);grid.append(b)});c.append(grid);
let foot=node("div","device-bottom");foot.append(node("span","",`Sequence: ${val(d.sequence)}`),node("span","",d.status||"Waiting for data"));c.append(foot);return c}
function renderInvestigation(events){
const root=document.getElementById("attack-investigation");
if(!root)return;
const e=events.find(x=>["POSSIBLE PACKET TAMPERING","REPLAY ATTACK"].includes(x.category));
root.replaceChildren();
root.append(node("div","investigation-title","Attack investigation"));
if(!e){root.append(node("div","investigation-empty","No tampering or replay event recorded yet. Run a controlled test to populate this panel."));return;}
const status=node("div","investigation-status",e.category==="REPLAY ATTACK"?"REPLAY ATTEMPT REJECTED":"POSSIBLE TAMPERING DETECTED");
root.append(status);
const grid=node("div","investigation-grid");
const fields=[
["When detected",e.date_time_local||e.time||"—",""],
["Device",`${e.device_name||"Unknown"} (${e.node_id||"—"})`,""],
["Source IP",e.ip||"—",""],
["Event",e.kind||"—",""],
["Detection method",e.detection_method||"—","investigation-wide"],
["What may have changed",e.suspected_change||e.message||"—","investigation-wide"],
["Evidence",e.evidence||e.message||"—","investigation-wide"],
["Sequence",e.sequence===null||e.sequence===undefined?"Unavailable (encrypted payload did not authenticate)":String(e.sequence),"investigation-wide"],
["Gateway action",e.action_taken||"rejected",""],
["Packet SHA-256",e.packet_sha256||"Not available","investigation-wide"]
];
fields.forEach(([label,value,extra])=>{
const box=node("div","investigation-field"+(extra?" "+extra:""));
box.append(node("small","",label),node("strong","",value));
grid.append(box);
});
root.append(grid);
}
function renderEvents(events){let root=document.getElementById("events");root.replaceChildren();if(!events.length){root.append(node("div","updated","No activity recorded yet."));return}
events.slice(0,14).forEach(e=>{let row=node("div","event"),msg=node("div","event-msg");row.append(node("div","event-time",e.time||""));msg.append(node("div","event-kind sev-"+(e.severity||"INFO"),e.kind||"EVENT"),node("div","",e.message||""));if(e.category==="POSSIBLE PACKET TAMPERING"||e.category==="REPLAY ATTACK"){msg.append(node("div","panel-sub",`${e.device_name||"Device"} • ${e.detection_method||"Security validation"} • ${e.action_taken||"rejected"}`))}row.append(msg,node("div","event-time",e.ip||""));root.append(row)})}
async function refresh(){try{let r=await fetch("/api/state",{cache:"no-store"});if(!r.ok)throw Error();let d=await r.json();
document.getElementById("connected").textContent=`${d.connected} / 4`;document.getElementById("secure").textContent=d.secure;document.getElementById("alerts").textContent=d.alert_count;document.getElementById("failed").textContent=d.failed_count;document.getElementById("gateway").textContent="ONLINE";document.getElementById("updated").textContent="Updated "+new Date().toLocaleTimeString();
let root=document.getElementById("devices");root.replaceChildren();let map=new Map((d.clients||[]).map(x=>[x.ip,x])),used=new Set();
known.forEach(k=>{let found=map.get(k.ip);if(found){root.append(card(found));used.add(found.client_id)}else root.append(card({device_name:k.name,sensors:k.sensors,ip:k.ip,client_id:"Not connected",connected:false,status:"Waiting for connection"}))});
(d.clients||[]).filter(x=>!used.has(x.client_id)&&!known.some(k=>k.ip===x.ip)).forEach(x=>root.append(card(x)));renderEvents(d.events||[]);renderInvestigation(d.events||[]);
}catch(e){document.getElementById("gateway").textContent="OFFLINE";document.getElementById("updated").textContent="Cannot reach local gateway"}}
document.querySelectorAll(".nav-item").forEach(link=>link.addEventListener("click",()=>{
document.querySelectorAll(".nav-item").forEach(item=>item.classList.remove("active"));
link.classList.add("active");
}));
refresh();setInterval(refresh,1500);
</script></body></html>"""


class DashboardHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/" or self.path.startswith("/?"):
            body = DASHBOARD_HTML.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        elif self.path == "/api/state":
            with STATE_LOCK:
                clients = [dict(v) for v in DASHBOARD_CLIENTS.values()]
                events = list(SECURITY_EVENTS)
            connected = sum(1 for c in clients if c.get("connected"))
            secure = sum(1 for c in clients if c.get("connected") and c.get("secure"))
            failed = sum(1 for e in events if e.get("severity") in ("HIGH", "CRITICAL"))
            body = json.dumps({
                "connected": connected, "secure": secure,
                "alert_count": failed, "failed_count": failed,
                "clients": clients, "events": events
            }).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        else:
            self.send_error(404)

    def log_message(self, fmt, *args):
        return


def start_dashboard():
    server = ThreadingHTTPServer((WEB_HOST, WEB_PORT), DashboardHandler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    safe_print(f"Dashboard available at http://127.0.0.1:{WEB_PORT}", flush=True)



def main():
    start_dashboard()
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind((HOST, PORT))
    server.listen(5)
    safe_print("=" * 64)
    safe_print("       SECURE PATIENT MONITORING - AES-256-GCM GATEWAY")
    safe_print("=" * 64)
    safe_print(f"Listening on {HOST}:{PORT}")
    safe_print(f"Open dashboard: http://127.0.0.1:{WEB_PORT}")
    safe_print("Waiting for up to five ESP32 clients...")
    safe_print("Connections use ESP32-01 to ESP32-04 labels based on the current hotspot IP map.")
    safe_print("ECDH key exchange format: newline-terminated ASCII hex (ESP32 firmware format).")
    safe_print("Security alerts are also appended to " + LOG_FILE)
    while True:
        conn, peer = server.accept()
        threading.Thread(target=handle_client, args=(conn, peer), daemon=True).start()

if __name__ == "__main__":
    main()
