# PulseGuard — Secure Patient Monitoring Gateway

PulseGuard is a local Python gateway and browser dashboard for a four-node ESP32 patient-monitoring prototype.

## Current device profile

| Device | Current hotspot IP | Sensors |
|---|---|---|
| ESP32-01 | `192.168.1.7` | MAX30102 + DHT11 |
| ESP32-02 | `192.168.1.9` | MAX30102 |
| ESP32-03 | `192.168.1.8` | DHT11 |
| ESP32-04 | `192.168.1.6` | DHT11 |

> **Important:** These are the DHCP addresses observed during the latest test. The current firmware handshake does not send a device ID, so the gateway currently maps devices by source IP. Reserve these DHCP leases or update `DEVICE_PROFILES` and the dashboard's `known` list in `gateway.py` if addresses change. This is a prototype limitation, not cryptographic device authentication.

## Security and data flow

- P-256 ECDH key agreement
- HKDF-SHA256 session-key derivation
- AES-256-GCM authenticated encryption/decryption
- Sequence-number replay check
- Rejected packet/security event logging

The gateway's cryptographic flow must be tested end-to-end with the exact ESP32 firmware before deployment. This repository is a student prototype, not a clinical medical device. Do not use its readings for diagnosis or treatment.

## Requirements

- Python 3.9+
- ESP32 Arduino firmware compatible with the newline-terminated hexadecimal P-256 public-key handshake and `NONCE|CIPHERTEXT|TAG` packet format
- ESP32 boards and sensors configured as shown above

Install Python dependencies:

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
```

## Run

```bash
python gateway.py
```

- TCP gateway: port `5000`
- Local dashboard: http://127.0.0.1:8080

Stop the gateway with `Ctrl+C`.

## Configuration notes

- `HOST`, `PORT`, `WEB_HOST`, and `WEB_PORT` are defined near the top of `gateway.py`.
- `DEVICE_PROFILES` maps the observed source IP addresses to ESP32 names and sensor profiles.
- The dashboard's `known` list mirrors the same four IP/name mappings.
- If the hotspot assigns different addresses, update both mappings consistently.

## Repository hygiene

Runtime logs such as `security_alerts.jsonl`, virtual environments, Python caches, and local secrets are excluded by `.gitignore`. Never commit Wi-Fi passwords, private keys, access tokens, or patient-identifiable data.
